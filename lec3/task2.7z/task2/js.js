'use strict'
const { table } = require('console')
const { reverse } = require('dns')
const fs = require('fs')
const path = require('path')
let textArray = []
let text1 = fs.readFileSync(`${__dirname}/text/f1.txt`, 'utf-8') //get text from file
let text2 = fs.readFileSync(`${__dirname}/text/f2.txt`, 'utf-8')
let text3 = fs.readFileSync(`${__dirname}/text/f3.txt`, 'utf-8')
textArray[0] = text1.split('\r\n')
textArray[1] = text2.split('\r\n')
textArray[2] = text3.split('\r\n')
//console.table(textArray);
let res 
let stop=0
let counter = 1

const allLines = []
const filesName = ['f1.txt', 'f2.txt', 'f3.txt']
let allLinesByColumns = [];
for(let i = 0; i < filesName.length; i++){
    let textInFile = fs.readFileSync(`${__dirname}/text/`+filesName[i], 'utf-8');
    allLines[i] = textInFile.split('\r\n');
  }
  //console.table(allLines)
function rotateRight(array) {
  var result = [];
  array.forEach(function (line, i) {
      line.forEach(function (elem, j, arr) {
          result[j] = result[j] || [];
          result[j][i] = elem;
      });
  });
  return result;
}
allLinesByColumns = rotateRight(allLines)
console.table(allLinesByColumns)
let tmp = ""
let i=0
let k=1
while(i<allLinesByColumns.length){
  for(let l=1;l<=k && i<allLinesByColumns.length;l++){
   // tmp +=allLinesByColumns[i]
    //console.log(allLinesByColumns[i]);console.log("sd")
    
    for(let j=0; j<3; j++){
      
      //if(allLinesByColumns[i][j])console.log(allLinesByColumns[i][j])
      if(allLinesByColumns[i][j] !== undefined){
        tmp += allLinesByColumns[i][j]
    }
    }
    // if(allLinesByColumns[i] !== undefined){
      
    // }
    // allLinesByColumns[i].forEach(function(num,j){
    //   //if(num!==undefined) tmp += allLinesByColumns[i][j] +" "
    // })
    i++
  }
  k++
  tmp+="\r\n"
}
console.log(tmp);

